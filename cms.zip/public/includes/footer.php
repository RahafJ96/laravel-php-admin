        <!-- Footer -->
        <footer class="sticky-footer" style="background-color:#EBEBEB; padding-top:20px;padding-bottom:10px">
        	<p class="text-center" style="font-size:large;">Footer</p>
        </footer>