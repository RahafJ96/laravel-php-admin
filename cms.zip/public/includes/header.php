<nav class="text-center" style="background-color:white;">
	<h1 style="color:#1E22A1; font-weight:bold;" >Header</h1>
	<hr style="width:70%;margin-left:15%">
	<br>
	
</nav>