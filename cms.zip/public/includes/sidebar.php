<ul class="sidebar-nav shadow">
            <li><a href="#">Dashboard</a></li>
            <li><a href="#">Product</a></li>
            <li><a href="#">Order</a></li>
            <li><a href="#">Chat</a></li>
            <li><a href="#">Special Pages</a></li>
            <li><a href="#">Documentation</a></li>
        </ul>